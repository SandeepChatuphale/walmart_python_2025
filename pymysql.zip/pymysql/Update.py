import pymysql

connection = pymysql.connect(host="localhost",user="root",password="root",database="accountdb");

cursor = connection.cursor();

id = 1;
balance = 1500;

updateQuery = "UPDATE tbl_account SET balance=%d WHERE id = %d" % (balance,id);
numberOfRowsAffected = cursor.execute(updateQuery);
connection.commit();    #by default commit is false hence commiting changes
connection.close();