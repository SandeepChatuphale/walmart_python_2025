import pymysql


connection = pymysql.connect(host="localhost",user="root",password="root",database="accountdb");

cursor = connection.cursor();

id = 1;
balance = 1000;
insertQuery = "INSERT INTO tbl_account (id,balance) VALUES('%d','%d')" % (id,balance);

numberOfRowsAffected = cursor.execute(insertQuery);
print('numberOfRowsAffected ',numberOfRowsAffected);
print(type(numberOfRowsAffected)); 
connection.commit();    
connection.close();