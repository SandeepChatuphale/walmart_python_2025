import pymysql

connection = pymysql.connect(host="localhost",user="root",password="root",database="accountdb");

cursor = connection.cursor();

id = 3;

findByIdQuery = 'DELETE FROM tbl_account WHERE id = %d' %(id);
connection.autocommit(True); 
numberOfRowsAffected = cursor.execute(findByIdQuery);
#connection.commit();    
connection.close();