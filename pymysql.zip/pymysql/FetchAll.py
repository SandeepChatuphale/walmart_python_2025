import pymysql

connection = pymysql.connect(host="localhost",user="root",password="root",database="accountdb");

cursor = connection.cursor();

findAllQuery = 'SELECT * FROM tbl_account';

numberOfRowsUpdated = cursor.execute(findAllQuery);
accounts = cursor.fetchall();

accountlist = [];
for a in accounts:    
    accountlist.append(a);
   
connection.close();