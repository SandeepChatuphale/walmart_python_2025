"""
Create a menu driven program-
Which shows 2 menus
1. Enter subject scores
2. Enter -1 to exit

Application MUST accept 3 subjects marks
Application MUST find total marks and average percentage

1) Make sure application accepts score not less than 0 and not more than 100.
   If NOT application MUST ignore this I/P.

Modify this project in such way that - 
create seperate function for each task
"""

# initialize variables
total_score = 0
average_score = 0


# display a welcome message
def show_menu():
    print("The Test Scores application")
    print()
    print("Enter test scores")
    print("Enter -1 to end input")
    print("======================")

def calculate_score():
    counter = 1
    global total_score
    global average_score

    while counter <= 3:
        test_score = int(input("Enter score of subject " +  str(counter) + " : " ))
        if test_score >= 0 and test_score <= 100:
            total_score += test_score
            counter += 1
        elif(test_score == -1):
            break
        else:
            print("Test score must be from 0 through 100. Score discarded. Try again.")

    counter -= 1
    # calculate average score
    average_score = (total_score / counter)

# format and display the result
def display_score():
    global total_score
    global average_score
    print("======================")
    print("Total Score:", total_score,"\nAverage Score:", average_score)

def show_footer():
    print("Thank you for visiting")

def main():
    show_menu()
    calculate_score()
    display_score()
    show_footer()

main()