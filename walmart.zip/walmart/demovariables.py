
a = 10.0;
print(type(a));

a = 10;
print(type(a));


a = 'sandeep';
print(type(a));

a = True
print(type(a));

a= [];
print(type(a));

a = ();
print(type(a));

a = {};
print(type(a));

int i = 10;
print(i)

