
for j in range(5):
    for i in range(6):
        print(i,end='');
    print(end='\n')


#---------------------------------------------------------------------------
list = ['Java','Python','C','Web'];
for name in list:
    print(name)
    
#---------------------------------------------------------------------------
tuple = ('Java','Python','C','Web');
for name in tuple:
    print(name)