"""
Create a menu driven program-
Which shows 2 menus
1. Enter subject scores
2. Enter -1 to exit

Application MUST accept 3 subjects marks
Application MUST find total marks and average percentage



Modify this project in such way that - 
1) Make sure application accepts score not less than 0 and not more than 100.
   If NOT application MUST ignore this I/P.

"""

# display a welcome message
print("The Test Scores application")
print()
print("Enter test scores")
print("Enter -1 to end input")
print("======================")

# initialize variables
counter = 1
total_score = 0
test_score = 0

while counter <= 3:
    test_score = int(input("Enter score of subject " +  str(counter) + " : " ))
    if test_score >= 0 and test_score <= 100:
        total_score += test_score
        counter += 1
    elif(test_score == -1):
        break
    else:
        print("Test score must be from 0 through 100. Score discarded. Try again.")

if(counter > 0):
    # calculate average score
    average_score = (total_score / counter)
                
    # format and display the result
    print("======================")
    print("Total Score:", total_score,"\nAverage Score:", average_score)

print()
print("Bye")
