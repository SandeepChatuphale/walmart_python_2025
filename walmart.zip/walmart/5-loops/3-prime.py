number = 5;
i = 2;
flag = True
while i<number:
    if number%i ==0:
        flag = False;
        break;
    i = i+1;

if(flag == True):
    print('prime');
else:
    print('Not');

print('-------------------------------------------------------------')
print("Using second approach")

number = 5;
i = 2;
while i<number:
    if number%i ==0:
        break;
    i = i+1;
else:
    print('prime');
