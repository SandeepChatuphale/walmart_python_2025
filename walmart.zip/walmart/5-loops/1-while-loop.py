i = 1;
while(i<=5):
    print('hi ' + str(i))
    i=i+1;
    
i = 1;
while i<=5:
    print('hi ' + str(i))
    i=i+1;