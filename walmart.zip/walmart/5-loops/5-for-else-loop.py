for i in range(6):
    print(i);    
else:
    print('First else - executed when loop completes normally');

#----------------------------------------------------------------
for i in range(6):
    print(i);    
    break;
else:
    print('Second else - NOT executed when loop terminates');

#---------------------------------------------------------------------------
# 1 - start  (inclusive)
# 6 - end (exclusive)
# 2 - steps
for i in range(1,6,2):
    print(i);
else:
    print('Third else - executed when loop completes normally');

#---------------------------------------------------------------------------
list = ['Java','Python','C','Web'];
for name in list:
    print(name)
else:
    print('Fourth else');
    
#---------------------------------------------------------------------------
tuple = ('Java','Python','C','Web');
for name in tuple:
    print(name)
else:
    print('Fifth else');