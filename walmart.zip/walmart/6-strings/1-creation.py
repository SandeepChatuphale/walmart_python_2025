str = 'Hello';      #using single quote
print(type(str))    #<class 'str'>
print(str)          #Hello

str = "India"       #using double quote
print(type(str))    #<class 'str'>
print(str)          #Hello


str = """ this is india """ #using triple quote
print(type(str))    #<class 'str'>
print(str)          #Hello

str = """ this is india
            very good""" #using triple quote for multi line string
print(type(str))    #<class 'str'>
print(str)          #Hello


#string is ammutable
print(str[3])
#str[0] = 'p';           #TypeError: 'str' object does not support item assignment

