str = ' hello this is python ';      #using single quote

print("str.upper()       \t =>" + str.upper())
print("str.lower()       \t =>" + str.lower())
print("str.capitalize()\t =>" +str.capitalize())
print("str.strip()\t         =>" +str.strip())

print("Original is unchanged    =>" + str)
print("str.strip().capitalize() =>" + str.strip().capitalize())
print(str.endswith('n'))              #False
print(str.join('Very good'))

words = str.split()
print(words)                #['Hello', 'this', 'is', 'python']
print(type(words))          #<class 'list'>

str = 'Happy new Year';
                    #Old        #New
print(str.replace('Happy','Happiest'))

str = "I,am,Sandeep"
words = str.split(",")
print(words)                #['I', 'am', 'Sandeep']
print(type(words))          #<class 'list'>



print('====================startswith===================')
str = "India";
print(str.startswith('i'))            #False
print(str.startswith('I'))            #True

print('====================endswith===================')
print(str.endswith('a'))            #True
print(str.endswith('A'))            #True


print('====================find===================')
str = "This is Python"
print("str.find('i') ==> ",str.find('i')) #2
print("str.find('i',3) ==> ",str.find('i',3)) #5
print("str.find('i',3,9) ==> ",str.find('i',6,9)) #-1


print('====================count===================')
print(str.count('i')) #count all occurences of i
print(str.count('T')) #count all occurences of i
print(str.count('p')) #count all occurences of i


print('====================center===================')
print(str.center(45))   #returns a centered string of specified size



print('=======================isXXX==========================')
str = "1+2"
print(str.isdigit())
print(str.isnumeric())

numeric_str = "½"
print(numeric_str.isdigit())  # Output: True
print(numeric_str.isnumeric())  # Output: True
print(str.isnumeric())


print('================================================')
print(str+" Is my Country");          #Concatation
print(str*2);                         #Print 2 times


print(ord('A'))                      #Unicode character
print(len(str))
