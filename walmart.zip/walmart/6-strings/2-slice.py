str = 'Hello this is python';      #using single quote


print(str);
s = str[0];
print(type(s))       ##<class 'str'>
print(str[0])        # prints string at index 0 - H
print(str[2:5])      # prints string from 2nd index to 5th index    (start inclusive end exclusive)                 
print(str[2:])       # prints string from 2nd till end
print(str[:8])       # prints string from beginning till 8th index
print(str[:-1])      # prints string from beginning till 8th index
                     #Hello this is pytho

print(str[-2:-1])      
print(type(str[1])) #<class 'str'>
print(str);             #Remains unchanged