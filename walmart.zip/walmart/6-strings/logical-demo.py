#2) WAP that counts the number of alphabets and digits, uppercase , lowercase letters in the string entered.

sentence = input("Enter your value: ") 
print(sentence)


digits = 0;
alphabets = 0
uppercase = 0;
lowercase = 0
space = 0

#visits each letter in string
for letter in sentence:
    if letter.isdigit():
        digits+=1
    elif letter.isalpha():
        alphabets+=1
        if letter.islower():
            lowercase += 1
        elif letter.isupper():
            uppercase += 1
        elif letter.isspace():
            space += 1
            print('space')

print('number of digits are ' + str(digits))
print('number of alphabets are ' + str(alphabets))
print('number of lower case characters are ' + str(lowercase))
print('number of upper case characters are ' + str(uppercase))
print('number of space characters are ' + str(space))
    
    

