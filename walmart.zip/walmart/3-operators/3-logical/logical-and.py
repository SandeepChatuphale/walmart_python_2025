age = 18;
nationality = 'indian';

if(age>=18 and nationality == 'indian'):
    print('Eligible for Voting')
