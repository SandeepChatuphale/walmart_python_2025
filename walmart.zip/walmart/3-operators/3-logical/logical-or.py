age = 18;
nationality = 'indian';

if(age or nationality):
    print('Eligible for Voting')

