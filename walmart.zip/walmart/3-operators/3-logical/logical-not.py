x = 5

print(not(x > 3 and x < 10))

