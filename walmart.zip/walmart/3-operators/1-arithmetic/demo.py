x = 20;
y = 6.0;

print('x+y = ' , x+y , '    type(x+y) is ', type(x+y))
print('x-y = ' , x-y , '    type(x-y) is ', type(x-y))
print('x*y = ' , x*y, '     type(x*y) is ', type(x*y))
print('x/y = ' , x/y, '     type(x/y) is ', type(x/y))
print('x//y = ' , x//y, '   type(x//y) is ', type(x//y))
print('x%y = ' , x%y, '     type(x&y) is ', type(x%y))


print('======================================================')

x = True;
y = True;

print('x+y = ' , x+y , '    type(x+y) is ', type(x+y))
print('x-y = ' , x-y , '    type(x-y) is ', type(x-y))
print('x*y = ' , x*y, '     type(x*y) is ', type(x*y))
print('x/y = ' , x/y, '     type(x/y) is ', type(x/y))
print('x//y = ' , x//y, '   type(x//y) is ', type(x//y))
print('x%y = ' , x%y, '     type(x&y) is ', type(x%y))
