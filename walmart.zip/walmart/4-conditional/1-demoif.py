age = 10;

if(age >= 18):
    print('Eligible for Voting')
else:
    print('Not Eligible for Voting');

#------------------------------------------------------------

age = 10;

if age >= 18:
    print('Eligible for Voting')
else:
    print('Not Eligible for Voting');
