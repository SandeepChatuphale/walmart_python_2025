num = 100;

if(num == 10):
    print(10)
elif(num==20):
    print(20);
elif(num==30):
    print(30);
else:
    print('Not')

